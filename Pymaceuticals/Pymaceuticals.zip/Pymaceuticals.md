

```python
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
```


```python
# Read CSV
mouse_data = pd.read_csv("Resources/mouse_drug_data.csv")
mouse_data.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Mouse ID</th>
      <th>Drug</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>f234</td>
      <td>Stelasyn</td>
    </tr>
    <tr>
      <th>1</th>
      <td>x402</td>
      <td>Stelasyn</td>
    </tr>
    <tr>
      <th>2</th>
      <td>a492</td>
      <td>Stelasyn</td>
    </tr>
    <tr>
      <th>3</th>
      <td>w540</td>
      <td>Stelasyn</td>
    </tr>
    <tr>
      <th>4</th>
      <td>v764</td>
      <td>Stelasyn</td>
    </tr>
  </tbody>
</table>
</div>




```python
drug_data = pd.read_csv("Resources/clinicaltrial_data.csv")
drug_data.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Mouse ID</th>
      <th>Timepoint</th>
      <th>Tumor Volume (mm3)</th>
      <th>Metastatic Sites</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>b128</td>
      <td>0</td>
      <td>45.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>f932</td>
      <td>0</td>
      <td>45.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>g107</td>
      <td>0</td>
      <td>45.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>a457</td>
      <td>0</td>
      <td>45.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>c819</td>
      <td>0</td>
      <td>45.0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
mouse_drug_df = pd.merge(mouse_data, drug_data, on='Mouse ID')
mouse_drug_df.head()

```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Mouse ID</th>
      <th>Drug</th>
      <th>Timepoint</th>
      <th>Tumor Volume (mm3)</th>
      <th>Metastatic Sites</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>f234</td>
      <td>Stelasyn</td>
      <td>0</td>
      <td>45.000000</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>f234</td>
      <td>Stelasyn</td>
      <td>5</td>
      <td>47.313491</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>f234</td>
      <td>Stelasyn</td>
      <td>10</td>
      <td>47.904324</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>f234</td>
      <td>Stelasyn</td>
      <td>15</td>
      <td>48.735197</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>f234</td>
      <td>Stelasyn</td>
      <td>20</td>
      <td>51.112713</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Tumor Response to Treatment

pv_df = pd.pivot_table(mouse_drug_df, index =['Drug','Timepoint'], values="Tumor Volume (mm3)")
pv_df.head()

```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>Tumor Volume (mm3)</th>
    </tr>
    <tr>
      <th>Drug</th>
      <th>Timepoint</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="5" valign="top">Capomulin</th>
      <th>0</th>
      <td>45.000000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>44.266086</td>
    </tr>
    <tr>
      <th>10</th>
      <td>43.084291</td>
    </tr>
    <tr>
      <th>15</th>
      <td>42.064317</td>
    </tr>
    <tr>
      <th>20</th>
      <td>40.716325</td>
    </tr>
  </tbody>
</table>
</div>




```python
capm_df = mouse_drug_df.loc[(mouse_drug_df['Drug']=='Capomulin')&(mouse_drug_df['Timepoint']<=20)]

pd.pivot_table(capm_df, index =['Drug','Timepoint'], values="Tumor Volume (mm3)")
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>Tumor Volume (mm3)</th>
    </tr>
    <tr>
      <th>Drug</th>
      <th>Timepoint</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="5" valign="top">Capomulin</th>
      <th>0</th>
      <td>45.000000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>44.266086</td>
    </tr>
    <tr>
      <th>10</th>
      <td>43.084291</td>
    </tr>
    <tr>
      <th>15</th>
      <td>42.064317</td>
    </tr>
    <tr>
      <th>20</th>
      <td>40.716325</td>
    </tr>
  </tbody>
</table>
</div>




```python
pd.pivot_table(mouse_drug_df, 'Tumor Volume (mm3)', 'Timepoint', 'Drug')
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Drug</th>
      <th>Capomulin</th>
      <th>Ceftamin</th>
      <th>Infubinol</th>
      <th>Ketapril</th>
      <th>Naftisol</th>
      <th>Placebo</th>
      <th>Propriva</th>
      <th>Ramicane</th>
      <th>Stelasyn</th>
      <th>Zoniferol</th>
    </tr>
    <tr>
      <th>Timepoint</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>45.000000</td>
      <td>45.000000</td>
      <td>45.000000</td>
      <td>45.000000</td>
      <td>45.000000</td>
      <td>45.000000</td>
      <td>45.000000</td>
      <td>45.000000</td>
      <td>45.000000</td>
      <td>45.000000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>44.266086</td>
      <td>46.503051</td>
      <td>47.062001</td>
      <td>47.389175</td>
      <td>46.796098</td>
      <td>47.125589</td>
      <td>47.248967</td>
      <td>43.944859</td>
      <td>47.527452</td>
      <td>46.851818</td>
    </tr>
    <tr>
      <th>10</th>
      <td>43.084291</td>
      <td>48.285125</td>
      <td>49.403909</td>
      <td>49.582269</td>
      <td>48.694210</td>
      <td>49.423329</td>
      <td>49.101541</td>
      <td>42.531957</td>
      <td>49.463844</td>
      <td>48.689881</td>
    </tr>
    <tr>
      <th>15</th>
      <td>42.064317</td>
      <td>50.094055</td>
      <td>51.296397</td>
      <td>52.399974</td>
      <td>50.933018</td>
      <td>51.359742</td>
      <td>51.067318</td>
      <td>41.495061</td>
      <td>51.529409</td>
      <td>50.779059</td>
    </tr>
    <tr>
      <th>20</th>
      <td>40.716325</td>
      <td>52.157049</td>
      <td>53.197691</td>
      <td>54.920935</td>
      <td>53.644087</td>
      <td>54.364417</td>
      <td>53.346737</td>
      <td>40.238325</td>
      <td>54.067395</td>
      <td>53.170334</td>
    </tr>
    <tr>
      <th>25</th>
      <td>39.939528</td>
      <td>54.287674</td>
      <td>55.715252</td>
      <td>57.678982</td>
      <td>56.731968</td>
      <td>57.482574</td>
      <td>55.504138</td>
      <td>38.974300</td>
      <td>56.166123</td>
      <td>55.432935</td>
    </tr>
    <tr>
      <th>30</th>
      <td>38.769339</td>
      <td>56.769517</td>
      <td>58.299397</td>
      <td>60.994507</td>
      <td>59.559509</td>
      <td>59.809063</td>
      <td>58.196374</td>
      <td>38.703137</td>
      <td>59.826738</td>
      <td>57.713531</td>
    </tr>
    <tr>
      <th>35</th>
      <td>37.816839</td>
      <td>58.827548</td>
      <td>60.742461</td>
      <td>63.371686</td>
      <td>62.685087</td>
      <td>62.420615</td>
      <td>60.350199</td>
      <td>37.451996</td>
      <td>62.440699</td>
      <td>60.089372</td>
    </tr>
    <tr>
      <th>40</th>
      <td>36.958001</td>
      <td>61.467895</td>
      <td>63.162824</td>
      <td>66.068580</td>
      <td>65.600754</td>
      <td>65.052675</td>
      <td>63.045537</td>
      <td>36.574081</td>
      <td>65.356386</td>
      <td>62.916692</td>
    </tr>
    <tr>
      <th>45</th>
      <td>36.236114</td>
      <td>64.132421</td>
      <td>65.755562</td>
      <td>70.662958</td>
      <td>69.265506</td>
      <td>68.084082</td>
      <td>66.258529</td>
      <td>34.955595</td>
      <td>68.438310</td>
      <td>65.960888</td>
    </tr>
  </tbody>
</table>
</div>




```python
pv_plot = mouse_drug_df.groupby(['Drug','Timepoint'],as_index=True).agg({'Tumor Volume (mm3)':['mean','sem']})
pv_plot.columns = pv_plot.columns.get_level_values(1)
pv_plot = pv_plot.reset_index()

plt.figure(figsize=(10,6))
names = ['Capomulin','Infubinol','Ketapril','Placebo']
style_list = ['ro','b^','gs','kD']

i=0
for name in names:
    capm = pv_plot.loc[pv_plot['Drug']==name]

    plt.errorbar(capm['Timepoint'], capm['mean'],yerr=capm['sem'],label=name, fmt = style_list[i],linestyle = '--',capsize= 4)
    i= i+1
    plt.legend(loc="best")

    plt.title("Tumor Response to Treatment")
    plt.xlabel("Time (Days)")
    plt.ylabel("Tumor Volume (mm3)")

plt.show()
```


![png](output_7_0.png)



```python
# Metastatic Response to Treatment

metaresponse_df = mouse_drug_df.iloc[:,[1,2,4]]
metaresponse_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Drug</th>
      <th>Timepoint</th>
      <th>Metastatic Sites</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Stelasyn</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Stelasyn</td>
      <td>5</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Stelasyn</td>
      <td>10</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Stelasyn</td>
      <td>15</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Stelasyn</td>
      <td>20</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
</div>




```python
meta_capm_df = metaresponse_df.loc[(metaresponse_df['Drug']=='Capomulin')&(metaresponse_df['Timepoint']<=20)]

pd.pivot_table(meta_capm_df, index =['Drug','Timepoint'], values="Metastatic Sites")
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>Metastatic Sites</th>
    </tr>
    <tr>
      <th>Drug</th>
      <th>Timepoint</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="5" valign="top">Capomulin</th>
      <th>0</th>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>0.160000</td>
    </tr>
    <tr>
      <th>10</th>
      <td>0.320000</td>
    </tr>
    <tr>
      <th>15</th>
      <td>0.375000</td>
    </tr>
    <tr>
      <th>20</th>
      <td>0.652174</td>
    </tr>
  </tbody>
</table>
</div>




```python
meta_pd = pd.pivot_table(metaresponse_df, 'Metastatic Sites', 'Timepoint', 'Drug')
meta_pd
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Drug</th>
      <th>Capomulin</th>
      <th>Ceftamin</th>
      <th>Infubinol</th>
      <th>Ketapril</th>
      <th>Naftisol</th>
      <th>Placebo</th>
      <th>Propriva</th>
      <th>Ramicane</th>
      <th>Stelasyn</th>
      <th>Zoniferol</th>
    </tr>
    <tr>
      <th>Timepoint</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>0.160000</td>
      <td>0.380952</td>
      <td>0.280000</td>
      <td>0.304348</td>
      <td>0.260870</td>
      <td>0.375000</td>
      <td>0.320000</td>
      <td>0.120000</td>
      <td>0.240000</td>
      <td>0.166667</td>
    </tr>
    <tr>
      <th>10</th>
      <td>0.320000</td>
      <td>0.600000</td>
      <td>0.666667</td>
      <td>0.590909</td>
      <td>0.523810</td>
      <td>0.833333</td>
      <td>0.565217</td>
      <td>0.250000</td>
      <td>0.478261</td>
      <td>0.500000</td>
    </tr>
    <tr>
      <th>15</th>
      <td>0.375000</td>
      <td>0.789474</td>
      <td>0.904762</td>
      <td>0.842105</td>
      <td>0.857143</td>
      <td>1.250000</td>
      <td>0.764706</td>
      <td>0.333333</td>
      <td>0.782609</td>
      <td>0.809524</td>
    </tr>
    <tr>
      <th>20</th>
      <td>0.652174</td>
      <td>1.111111</td>
      <td>1.050000</td>
      <td>1.210526</td>
      <td>1.150000</td>
      <td>1.526316</td>
      <td>1.000000</td>
      <td>0.347826</td>
      <td>0.952381</td>
      <td>1.294118</td>
    </tr>
    <tr>
      <th>25</th>
      <td>0.818182</td>
      <td>1.500000</td>
      <td>1.277778</td>
      <td>1.631579</td>
      <td>1.500000</td>
      <td>1.941176</td>
      <td>1.357143</td>
      <td>0.652174</td>
      <td>1.157895</td>
      <td>1.687500</td>
    </tr>
    <tr>
      <th>30</th>
      <td>1.090909</td>
      <td>1.937500</td>
      <td>1.588235</td>
      <td>2.055556</td>
      <td>2.066667</td>
      <td>2.266667</td>
      <td>1.615385</td>
      <td>0.782609</td>
      <td>1.388889</td>
      <td>1.933333</td>
    </tr>
    <tr>
      <th>35</th>
      <td>1.181818</td>
      <td>2.071429</td>
      <td>1.666667</td>
      <td>2.294118</td>
      <td>2.266667</td>
      <td>2.642857</td>
      <td>2.300000</td>
      <td>0.952381</td>
      <td>1.562500</td>
      <td>2.285714</td>
    </tr>
    <tr>
      <th>40</th>
      <td>1.380952</td>
      <td>2.357143</td>
      <td>2.100000</td>
      <td>2.733333</td>
      <td>2.466667</td>
      <td>3.166667</td>
      <td>2.777778</td>
      <td>1.100000</td>
      <td>1.583333</td>
      <td>2.785714</td>
    </tr>
    <tr>
      <th>45</th>
      <td>1.476190</td>
      <td>2.692308</td>
      <td>2.111111</td>
      <td>3.363636</td>
      <td>2.538462</td>
      <td>3.272727</td>
      <td>2.571429</td>
      <td>1.250000</td>
      <td>1.727273</td>
      <td>3.071429</td>
    </tr>
  </tbody>
</table>
</div>




```python
meta_pd1 = mouse_drug_df.groupby(['Drug','Timepoint'],as_index=True).agg({'Metastatic Sites':['mean','sem']})
meta_pd1.columns = meta_pd1.columns.get_level_values(1)
meta_pd1 = meta_pd1.reset_index()

#meta_pv_df = pd.pivot_table(metaresponse_df, index =['Drug','Timepoint'], values="Metastatic Sites")

#meta_pd1= meta_pv_df.reset_index()
#meta_pd1

plt.figure(figsize=(10,6))
#names = ['Capomulin','Infubinol','Ketapril','Placebo']
#style_list = ['ro','b^','gs','kD']
i = 0
for name in names:
    capm = meta_pd1.loc[meta_pd1['Drug']==name]
#    plt.plot(capm['Timepoint'], capm['Metastatic Sites'], style_list[i], label=name)
    plt.errorbar(capm['Timepoint'], capm['mean'],yerr=capm['sem'],label=name, fmt = style_list[i],linestyle = '--',capsize= 4)

    i = i+1
    plt.xlabel("Time (Days)")
    plt.ylabel("Met. Sites")
    plt.title("Metastatic Spread During Treatment")
    plt.legend(loc="best")
    
plt.show()

```


![png](output_11_0.png)



```python
# Survival Rate

survival_df = mouse_drug_df.iloc[:,[0,1,2]]
survival_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Mouse ID</th>
      <th>Drug</th>
      <th>Timepoint</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>f234</td>
      <td>Stelasyn</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>f234</td>
      <td>Stelasyn</td>
      <td>5</td>
    </tr>
    <tr>
      <th>2</th>
      <td>f234</td>
      <td>Stelasyn</td>
      <td>10</td>
    </tr>
    <tr>
      <th>3</th>
      <td>f234</td>
      <td>Stelasyn</td>
      <td>15</td>
    </tr>
    <tr>
      <th>4</th>
      <td>f234</td>
      <td>Stelasyn</td>
      <td>20</td>
    </tr>
  </tbody>
</table>
</div>




```python

survival_group_df = pd.pivot_table(mouse_drug_df, index =['Drug','Timepoint'], values='Mouse ID', aggfunc='count')
survival_group_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>Mouse ID</th>
    </tr>
    <tr>
      <th>Drug</th>
      <th>Timepoint</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="5" valign="top">Capomulin</th>
      <th>0</th>
      <td>25</td>
    </tr>
    <tr>
      <th>5</th>
      <td>25</td>
    </tr>
    <tr>
      <th>10</th>
      <td>25</td>
    </tr>
    <tr>
      <th>15</th>
      <td>24</td>
    </tr>
    <tr>
      <th>20</th>
      <td>23</td>
    </tr>
  </tbody>
</table>
</div>




```python
capm_group_df1 =mouse_drug_df.loc[(mouse_drug_df['Drug']=='Capomulin') & (mouse_drug_df['Timepoint']<=20)]
capm_group_df1= capm_group_df1.rename(columns={'Mouse ID':'Mouse Count'})
pd.pivot_table(capm_group_df1, index =['Drug','Timepoint'], values="Mouse Count",aggfunc='count')
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>Mouse Count</th>
    </tr>
    <tr>
      <th>Drug</th>
      <th>Timepoint</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="5" valign="top">Capomulin</th>
      <th>0</th>
      <td>25</td>
    </tr>
    <tr>
      <th>5</th>
      <td>25</td>
    </tr>
    <tr>
      <th>10</th>
      <td>25</td>
    </tr>
    <tr>
      <th>15</th>
      <td>24</td>
    </tr>
    <tr>
      <th>20</th>
      <td>23</td>
    </tr>
  </tbody>
</table>
</div>




```python
survival_df = survival_group_df.reset_index()
survival_df = survival_df.rename(columns={'Mouse ID':'Mouse Count'})
survival_df2 = pd.pivot_table(survival_df, 'Mouse Count', 'Timepoint', 'Drug')
survival_df2
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Drug</th>
      <th>Capomulin</th>
      <th>Ceftamin</th>
      <th>Infubinol</th>
      <th>Ketapril</th>
      <th>Naftisol</th>
      <th>Placebo</th>
      <th>Propriva</th>
      <th>Ramicane</th>
      <th>Stelasyn</th>
      <th>Zoniferol</th>
    </tr>
    <tr>
      <th>Timepoint</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>25</td>
      <td>25</td>
      <td>25</td>
      <td>25</td>
      <td>25</td>
      <td>25</td>
      <td>26</td>
      <td>25</td>
      <td>26</td>
      <td>25</td>
    </tr>
    <tr>
      <th>5</th>
      <td>25</td>
      <td>21</td>
      <td>25</td>
      <td>23</td>
      <td>23</td>
      <td>24</td>
      <td>25</td>
      <td>25</td>
      <td>25</td>
      <td>24</td>
    </tr>
    <tr>
      <th>10</th>
      <td>25</td>
      <td>20</td>
      <td>21</td>
      <td>22</td>
      <td>21</td>
      <td>24</td>
      <td>23</td>
      <td>24</td>
      <td>23</td>
      <td>22</td>
    </tr>
    <tr>
      <th>15</th>
      <td>24</td>
      <td>19</td>
      <td>21</td>
      <td>19</td>
      <td>21</td>
      <td>20</td>
      <td>17</td>
      <td>24</td>
      <td>23</td>
      <td>21</td>
    </tr>
    <tr>
      <th>20</th>
      <td>23</td>
      <td>18</td>
      <td>20</td>
      <td>19</td>
      <td>20</td>
      <td>19</td>
      <td>17</td>
      <td>23</td>
      <td>21</td>
      <td>17</td>
    </tr>
    <tr>
      <th>25</th>
      <td>22</td>
      <td>18</td>
      <td>18</td>
      <td>19</td>
      <td>18</td>
      <td>17</td>
      <td>14</td>
      <td>23</td>
      <td>19</td>
      <td>16</td>
    </tr>
    <tr>
      <th>30</th>
      <td>22</td>
      <td>16</td>
      <td>17</td>
      <td>18</td>
      <td>15</td>
      <td>15</td>
      <td>13</td>
      <td>23</td>
      <td>18</td>
      <td>15</td>
    </tr>
    <tr>
      <th>35</th>
      <td>22</td>
      <td>14</td>
      <td>12</td>
      <td>17</td>
      <td>15</td>
      <td>14</td>
      <td>10</td>
      <td>21</td>
      <td>16</td>
      <td>14</td>
    </tr>
    <tr>
      <th>40</th>
      <td>21</td>
      <td>14</td>
      <td>10</td>
      <td>15</td>
      <td>15</td>
      <td>12</td>
      <td>9</td>
      <td>20</td>
      <td>12</td>
      <td>14</td>
    </tr>
    <tr>
      <th>45</th>
      <td>21</td>
      <td>13</td>
      <td>9</td>
      <td>11</td>
      <td>13</td>
      <td>11</td>
      <td>7</td>
      <td>20</td>
      <td>11</td>
      <td>14</td>
    </tr>
  </tbody>
</table>
</div>




```python
original_count_df = survival_df.loc[survival_df['Timepoint']==0]
original_count_df=original_count_df.iloc[:,[0,2]]      
original_count_df=original_count_df.rename(columns={'Mouse Count':'Original Mouse Count'})
survival_rate_df = pd.merge(survival_df, original_count_df, on='Drug')
survival_rate_df['Survival Rate']= survival_rate_df['Mouse Count']/survival_rate_df['Original Mouse Count']
survival_rate_df['sem']= np.sqrt(survival_rate_df['Survival Rate']*(1-survival_rate_df['Survival Rate'])/survival_rate_df['Original Mouse Count'])
survival_rate_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Drug</th>
      <th>Timepoint</th>
      <th>Mouse Count</th>
      <th>Original Mouse Count</th>
      <th>Survival Rate</th>
      <th>sem</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Capomulin</td>
      <td>0</td>
      <td>25</td>
      <td>25</td>
      <td>1.00</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Capomulin</td>
      <td>5</td>
      <td>25</td>
      <td>25</td>
      <td>1.00</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Capomulin</td>
      <td>10</td>
      <td>25</td>
      <td>25</td>
      <td>1.00</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Capomulin</td>
      <td>15</td>
      <td>24</td>
      <td>25</td>
      <td>0.96</td>
      <td>0.039192</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Capomulin</td>
      <td>20</td>
      <td>23</td>
      <td>25</td>
      <td>0.92</td>
      <td>0.054259</td>
    </tr>
  </tbody>
</table>
</div>




```python
#names = ['Capomulin','Infubinol','Ketapril','Placebo']
#style_list = ['ro--','b^--','gs--','kD--']

i = 0
plt.figure(figsize=(10,6))
for name in names:
    capm =survival_rate_df.loc[survival_rate_df['Drug']==name]
#    plt.plot(capm['Timepoint'], capm['Survival Rate'], style_list[i], label=name)
    plt.errorbar(capm['Timepoint'], capm['Survival Rate'],yerr=capm['sem'],label=name, fmt = style_list[i],linestyle = '--',capsize= 4)

    i = i+1
    plt.grid()
    plt.title("Survival During Treatment")
    plt.xlabel("Time (Days)")
    plt.ylabel("Survival Rate (%)")
    plt.legend(loc="best")
plt.show()

```


![png](output_17_0.png)



```python
# Summary Bar Graph
volume_drug_df1= mouse_drug_df.loc[mouse_drug_df['Timepoint']==0]
volume_drug_df1= volume_drug_df1.rename(columns={'Tumor Volume (mm3)':'Volume 0'})

volume_drug_df2= mouse_drug_df.loc[mouse_drug_df['Timepoint']==45]
volume_drug_df2= volume_drug_df2.rename(columns={'Tumor Volume (mm3)':'Volume 45'})

volume_drug = pd.merge(volume_drug_df1, volume_drug_df2, on = 'Mouse ID')
volume_drug = volume_drug.iloc[:,[0,1,3,7]]
volume_drug = volume_drug.rename(columns={'Drug_x':'Drug'})
volume_drug['volume change']= (volume_drug['Volume 45']-volume_drug['Volume 0'])/volume_drug['Volume 0']*100
volume_drug= volume_drug.iloc[:,[1,4]]
volume_change_rate_df = volume_drug.groupby('Drug')
volume_change =volume_change_rate_df.describe()
volume_change1 = pd.DataFrame(volume_change['volume change']['mean'])
volume_change1 = volume_change1.reset_index()
volume_change1 = volume_change1.rename(columns={'mean':'Volume Change %'})
print(volume_change1)
                                                                                        
                                                                                                                                                                        
```

            Drug  Volume Change %
    0  Capomulin       -19.475303
    1   Ceftamin        42.516492
    2  Infubinol        46.123472
    3   Ketapril        57.028795
    4   Naftisol        53.923347
    5    Placebo        51.297960
    6   Propriva        47.241175
    7   Ramicane       -22.320900
    8   Stelasyn        52.085134
    9  Zoniferol        46.579751
    


```python
names = ['Capomulin','Infubinol','Ketapril','Placebo']

tumor_rate_final = volume_change1.loc[(volume_change1['Drug']=='Capomulin')| (volume_change1['Drug']=='Infubinol')|(volume_change1['Drug']=='Ketapril') |(volume_change1['Drug']=='Placebo')]
  
ax =tumor_rate_final.plot(x='Drug', y='Volume Change %', kind='bar',alpha=0.5, linewidth =3, align="edge", facecolor = 'red',edgecolor = 'black',figsize=(10,6))

#for i in range(0,len(names)):
#    if tumor_rate_final['Volume Change %'].iloc[i]<0:
  #      ax.patches[i].set_color('green')

i=0
for v in tumor_rate_final['Volume Change %']:
    if v<0:
           ax.patches[i].set_facecolor('green')
    i=i+1
    
x_axis = np.arange(len(names))
tick_locations = [value+0.2 for value in x_axis]

plt.xticks(tick_locations, names,rotation=0 )
plt.grid(linestyle='dotted')
plt.title("Tumor Change Over 45 Days Treatment")

plt.ylabel("Tumor Volume Change (%)")
labels = [ "{:.1f}".format(i)+"%" for i in tumor_rate_final['Volume Change %']]
rects = ax.patches
for rect, label in zip(rects, labels):
    height = rect.get_height()
    ax.text(rect.get_x() + rect.get_width()/2, (height + 5)/2, label, ha='center', va='bottom')
plt.show()
```


![png](output_19_0.png)



```python
volume_change
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr>
      <th></th>
      <th colspan="8" halign="left">volume change</th>
    </tr>
    <tr>
      <th></th>
      <th>count</th>
      <th>mean</th>
      <th>std</th>
      <th>min</th>
      <th>25%</th>
      <th>50%</th>
      <th>75%</th>
      <th>max</th>
    </tr>
    <tr>
      <th>Drug</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Capomulin</th>
      <td>21.0</td>
      <td>-19.475303</td>
      <td>12.464376</td>
      <td>-48.125338</td>
      <td>-28.050318</td>
      <td>-17.084787</td>
      <td>-10.757288</td>
      <td>5.968807</td>
    </tr>
    <tr>
      <th>Ceftamin</th>
      <td>13.0</td>
      <td>42.516492</td>
      <td>7.229993</td>
      <td>32.759779</td>
      <td>36.519761</td>
      <td>42.888511</td>
      <td>50.061072</td>
      <td>53.162632</td>
    </tr>
    <tr>
      <th>Infubinol</th>
      <td>9.0</td>
      <td>46.123472</td>
      <td>7.629516</td>
      <td>35.375037</td>
      <td>39.454336</td>
      <td>46.851258</td>
      <td>50.412375</td>
      <td>60.503846</td>
    </tr>
    <tr>
      <th>Ketapril</th>
      <td>11.0</td>
      <td>57.028795</td>
      <td>10.710387</td>
      <td>39.798757</td>
      <td>49.175924</td>
      <td>55.271668</td>
      <td>64.450539</td>
      <td>74.593364</td>
    </tr>
    <tr>
      <th>Naftisol</th>
      <td>13.0</td>
      <td>53.923347</td>
      <td>11.348379</td>
      <td>39.268353</td>
      <td>42.103645</td>
      <td>54.585824</td>
      <td>64.150766</td>
      <td>70.375150</td>
    </tr>
    <tr>
      <th>Placebo</th>
      <td>11.0</td>
      <td>51.297960</td>
      <td>9.962592</td>
      <td>30.299937</td>
      <td>46.568489</td>
      <td>53.428535</td>
      <td>58.859537</td>
      <td>62.695419</td>
    </tr>
    <tr>
      <th>Propriva</th>
      <td>7.0</td>
      <td>47.241175</td>
      <td>11.103840</td>
      <td>30.296454</td>
      <td>41.225308</td>
      <td>44.350137</td>
      <td>56.289485</td>
      <td>61.012047</td>
    </tr>
    <tr>
      <th>Ramicane</th>
      <td>20.0</td>
      <td>-22.320900</td>
      <td>12.192086</td>
      <td>-50.999719</td>
      <td>-31.152944</td>
      <td>-22.558606</td>
      <td>-14.425988</td>
      <td>0.490820</td>
    </tr>
    <tr>
      <th>Stelasyn</th>
      <td>11.0</td>
      <td>52.085134</td>
      <td>11.619655</td>
      <td>33.604468</td>
      <td>42.341004</td>
      <td>53.998109</td>
      <td>61.271337</td>
      <td>66.941532</td>
    </tr>
    <tr>
      <th>Zoniferol</th>
      <td>14.0</td>
      <td>46.579751</td>
      <td>8.344526</td>
      <td>35.006009</td>
      <td>39.151442</td>
      <td>45.965975</td>
      <td>51.870585</td>
      <td>62.943183</td>
    </tr>
  </tbody>
</table>
</div>




```python
pv_2 = mouse_drug_df.groupby(['Drug','Timepoint'],as_index=True).agg({'Tumor Volume (mm3)':['mean','sem']})
pv_2.columns = pv_2.columns.get_level_values(1)
pv_2.reset_index().head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Drug</th>
      <th>Timepoint</th>
      <th>mean</th>
      <th>sem</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Capomulin</td>
      <td>0</td>
      <td>45.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Capomulin</td>
      <td>5</td>
      <td>44.266086</td>
      <td>0.448593</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Capomulin</td>
      <td>10</td>
      <td>43.084291</td>
      <td>0.702684</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Capomulin</td>
      <td>15</td>
      <td>42.064317</td>
      <td>0.838617</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Capomulin</td>
      <td>20</td>
      <td>40.716325</td>
      <td>0.909731</td>
    </tr>
  </tbody>
</table>
</div>




```python
pv_plot = mouse_drug_df.groupby(['Drug','Timepoint'],as_index=True).agg({'Tumor Volume (mm3)':['mean','sem']})
pv_plot.columns = pv_plot.columns.get_level_values(1)
pv_plot = pv_plot.reset_index()
```


```python
capm = pv_plot.loc[pv_plot['Drug']=='Capomulin']
capm
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Drug</th>
      <th>Timepoint</th>
      <th>mean</th>
      <th>sem</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Capomulin</td>
      <td>0</td>
      <td>45.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Capomulin</td>
      <td>5</td>
      <td>44.266086</td>
      <td>0.448593</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Capomulin</td>
      <td>10</td>
      <td>43.084291</td>
      <td>0.702684</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Capomulin</td>
      <td>15</td>
      <td>42.064317</td>
      <td>0.838617</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Capomulin</td>
      <td>20</td>
      <td>40.716325</td>
      <td>0.909731</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Capomulin</td>
      <td>25</td>
      <td>39.939528</td>
      <td>0.881642</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Capomulin</td>
      <td>30</td>
      <td>38.769339</td>
      <td>0.934460</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Capomulin</td>
      <td>35</td>
      <td>37.816839</td>
      <td>1.052241</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Capomulin</td>
      <td>40</td>
      <td>36.958001</td>
      <td>1.223608</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Capomulin</td>
      <td>45</td>
      <td>36.236114</td>
      <td>1.223977</td>
    </tr>
  </tbody>
</table>
</div>


